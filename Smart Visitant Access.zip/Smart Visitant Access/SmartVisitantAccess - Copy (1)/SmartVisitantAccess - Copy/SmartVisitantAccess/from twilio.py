from twilio.rest import Client

# Your Twilio credentials
account_sid = 'ACb37dea68c181db6d10505c4e1b3ee391'  # Replace with your Twilio Account SID
auth_token = 'b1fec01348cbeb155233d10316071b86'    # Replace with your Twilio Auth Token
twilio_number = '+12185212454'  # Replace with your Twilio phone number

# Function to send a link via SMS
def send_link(phone_number, link):
    client = Client(account_sid, auth_token)  # Initialize Twilio client
    
    # Message body with the link
    message_body = f"Here is your registration link: {link}"
    
    # Send SMS with the link
    message = client.messages.create(
        body=message_body,
        from_=twilio_number,
        to=phone_number
    )
    
    print(f"Link sent to {phone_number}: {link}")

# Replace with the recipient's phone number
recipient_number = '+919566248951'  # Replace with the recipient's phone number (include country code)
registration_link = "https://formfacade.com/pr/CLc4PCibZ/be677933ffddc80cc45c14d8a060ccfd"  # The link you want to send

# Send the registration link
send_link(recipient_number, registration_link)
