import cv2
import pytesseract
import os
import time
import numpy as np

# Set Tesseract path
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# Set the directory where the image will be saved
output_dir = r"C:\sample images"
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Function to preprocess and extract text using Tesseract OCR
def extract_text_from_image(image_path):
    image = cv2.imread(image_path)
    # Preprocess the image for better OCR accuracy
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # Denoising (using GaussianBlur)
    gray = cv2.GaussianBlur(gray, (5, 5), 0)

    # Thresholding: adaptive thresholding to deal with varying lighting conditions
    thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                  cv2.THRESH_BINARY, 11, 2)
    
    # Optionally sharpen the image to improve text clarity
    kernel = np.array([[0, -1, 0], [-1, 5,-1], [0, -1, 0]])
    sharpened = cv2.filter2D(thresh, -1, kernel)

    # OCR extraction with Tesseract
    custom_config = r'--oem 3 --psm 6'  # OCR Engine Mode (OEM 3 is default, but you can test others)
    text = pytesseract.image_to_string(sharpened, lang='eng', config=custom_config)
    return text

# Initialize camera
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("Error: Could not open camera.")
    exit()

# Define bounding box size (horizontal orientation)
box_width = 500  # Width of the bounding box
box_height = 300  # Height of the bounding box

# Flags to control image capture and countdown
image_captured = False
countdown_started = False

while True:
    ret, frame = cap.read()
    if not ret:
        print("Failed to capture frame.")
        break

    # Get frame dimensions
    height, width, _ = frame.shape

    # Center the bounding box horizontally
    x1 = (width - box_width) // 2
    y1 = (height - box_height) // 2
    x2 = x1 + box_width
    y2 = y1 + box_height

    # Draw bounding box on the live feed
    cv2.rectangle(frame, (x1, y1), (x2, y2), (255, 0, 0), 2)

    # Instructions for the user
    cv2.putText(frame, "Place your ID card inside the box.", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    # Start a countdown if it's not started
    if not countdown_started:
        for i in range(5, 0, -1):  # Countdown for 5 seconds
            temp_frame = frame.copy()
            cv2.putText(temp_frame, f"Capturing in {i} seconds...", (10, 60),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)
            cv2.imshow("Camera", temp_frame)
            cv2.waitKey(1000)  # Wait for 1 second
        countdown_started = True

    if not image_captured and countdown_started:
        # Capture the card image
        card_image = frame[y1:y2, x1:x2]
        if card_image.shape[0] > 0 and card_image.shape[1] > 0:
            # Save the captured card image
            image_path = os.path.join(output_dir, "bounded_card.jpg")
            cv2.imwrite(image_path, card_image)
            print(f"Card image saved as {image_path}")

            # Perform OCR on the captured image
            extracted_text = extract_text_from_image(image_path)
            print("Extracted Text:")
            print(extracted_text)

            if extracted_text.strip():
                print("OCR extraction successful!")
            else:
                print("OCR failed to extract text. Try repositioning the card or adjusting lighting.")
            
            # Stop the program after extraction
            image_captured = True

    # Display the live camera feed
    cv2.imshow("Camera", frame)

    if image_captured:
        print("Extraction complete. Closing program...")
        break

# Release the camera and close all windows
cap.release()
cv2.destroyAllWindows()
