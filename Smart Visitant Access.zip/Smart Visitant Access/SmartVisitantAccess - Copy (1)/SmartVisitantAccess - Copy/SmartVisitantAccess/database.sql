CREATE TABLE visitors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  age INT NOT NULL,
  email VARCHAR(255) NOT NULL,
  purpose VARCHAR(255) NOT NULL,
  photo LONGBLOB,  -- Add this line to store the photo
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE softcopies (
  id INT AUTO_INCREMENT PRIMARY KEY,
  filename VARCHAR(255) NOT NULL,
  extracted_text TEXT NOT NULL,
  photo LONGBLOB,  -- Add this line to store the photo
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE hardcopy_documents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  extracted_text TEXT,
  photo LONGBLOB,  -- Add this line to store the photo
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);