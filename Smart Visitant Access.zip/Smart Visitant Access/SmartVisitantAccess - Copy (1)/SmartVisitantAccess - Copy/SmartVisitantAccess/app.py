from flask import Flask, render_template, request, redirect, url_for, jsonify
import mysql.connector
import pytesseract
from werkzeug.utils import secure_filename
import os
import tempfile
import logging
from io import BytesIO
from PIL import Image

app = Flask(__name__)

# Specify the path to the Tesseract executable
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

# Database configuration
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # Make sure the password is correct
    'database': 'visitordb'  # Your database name in phpMyAdmin
}

# Set allowed extensions for file uploads
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    """Check if the uploaded file is allowed."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def get_db_connection():
    """Create a database connection."""
    try:
        connection = mysql.connector.connect(**db_config)
        if connection.is_connected():
            logging.info("Successfully connected to the database.")
        return connection
    except mysql.connector.Error as err:
        logging.error(f"Error: {err}")
        return None

@app.route('/')
def home():
    """Render the home page."""
    return render_template('home.html')


# Route for the login form

@app.route('/verify_login', methods=['GET', 'POST'])
def records_login():
    """Handle user login for record access."""
    if request.method == 'POST':
        name = request.form['name']
        password = request.form['password']
        if name == "admin" and password == "password123":
            return redirect(url_for('record'))
        else:
            error = "Invalid name or password. Please try again."
            return render_template('records_login.html', error=error)
    return render_template('records_login.html')

@app.route('/record')
def record():
    """Render the record service page."""
    return render_template('record.html')

@app.route('/registration', methods=['GET', 'POST'])
def registration():
    """Render the registration page and handle form submission."""
    if request.method == 'POST':
        visitorName = request.form['visitorName']
        age = request.form['age']
        email = request.form['email']
        purpose = request.form['purpose']

        # Insert the data into the database
        try:
            connection = get_db_connection()
            if connection:
                cursor = connection.cursor()
                cursor.execute(
                    "INSERT INTO visitors (name, age, email, purpose) VALUES (%s, %s, %s, %s)",
                    (visitorName, age, email, purpose)
                )
                connection.commit()
                cursor.close()
                connection.close()

                print("Data inserted successfully!")  # Debug message
                return redirect(url_for('home'))
            else:
                return "Database connection error"
        except Exception as e:
            print(f"Error: {e}")  # Print any error that occurs
            return "There was an error inserting the data."

    return render_template('registration.html')

@app.route('/hardcopy', methods=['GET', 'POST'])
def hardcopy():
    if request.method == 'POST':
        try:
            data = request.get_json()  # Receive the JSON data from the frontend
            extracted_text = data.get('extractedText')  # Extract the text from the request

            if not extracted_text:
                return jsonify({'status': 'error', 'message': 'No extracted text received.'})

            # Insert the extracted text into the database
            connection = get_db_connection()
            if connection:
                cursor = connection.cursor()
                cursor.execute(
                    "INSERT INTO hardcopy_documents (extracted_text) VALUES (%s)",
                    (extracted_text,)
                )
                connection.commit()
                cursor.close()
                connection.close()

                return jsonify({'status': 'success', 'message': 'Data saved successfully.'})
            else:
                return jsonify({'status': 'error', 'message': 'Database connection failed.'})

        except Exception as e:
            print(f"Error: {e}")
            return jsonify({'status': 'error', 'message': 'An error occurred while processing the request.'})

    return render_template('hardcopy.html')  # Serve the page for GET requests

@app.route('/hardcopy_record')
def hardcopy_record():
    """Retrieve and display all hardcopy records."""
    records = []
    connection = None  # Initialize the connection variable
    try:
        # Directly define the database connection parameters
        connection = mysql.connector.connect(
            host='localhost',            # Your database host (can be 'localhost' or IP address)
            user='root',        # Your database username
            password='',    # Your database password
            database='visitordb'         # Your database name
        )
        
        # Check if the connection was successful
        if connection.is_connected():
            cursor = connection.cursor(dictionary=True)  # Use dictionary cursor to get results as a dictionary
            cursor.execute("SELECT id,extracted_text,created_at FROM hardcopy_documents")  # Query to fetch records
            records = cursor.fetchall()  # Fetch all records
            cursor.close()  # Close the cursor
        else:
            print("Failed to connect to the database.")
            return jsonify({'status': 'error', 'message': 'Failed to connect to the database.'}), 500
    except Exception as e:
        print(f"Error retrieving data: {e}")  # Log any errors
        return jsonify({'status': 'error', 'message': 'An error occurred while fetching records.'}), 500
    finally:
        # Ensure the connection is closed after the operation
        if connection:
            connection.close()

    # If everything goes well, render the template with the records
    return render_template('hardcopy_record.html', records=records)



@app.route('/softcopy', methods=['GET', 'POST'])
def softcopy():
    """Render the softcopy page and handle image uploads or camera capture."""
    extracted_text = ""

    # Ensure the uploads directory exists
    if not os.path.exists('uploads'):
        os.makedirs('uploads')

    if request.method == 'POST':
        if 'file' in request.files:
            file = request.files['file']
            if file and allowed_file(file.filename):
                # Handle file upload
                file_path = os.path.join('uploads', secure_filename(file.filename))
                file.save(file_path)

                # Perform OCR on the uploaded file
                extracted_text = pytesseract.image_to_string(file_path)

                # Insert the extracted text into the database
                connection = get_db_connection()
                if connection:
                    cursor = connection.cursor()
                    cursor.execute(
                        "INSERT INTO softcopies (filename, extracted_text) VALUES (%s, %s)",
                        (secure_filename(file.filename), extracted_text)
                    )
                    connection.commit()
                    cursor.close()
                    connection.close()

                return render_template('softcopy.html', extracted_text=extracted_text)

        elif 'file' in request.form:
            # Handle base64 image capture from camera
            data_url = request.form['file']  # Capture the base64 string
            img_data = data_url.split(",")[1]  # Extract the image part (after the comma)
            img_binary = BytesIO(base64.b64decode(img_data))  # Convert base64 to binary

            # Use PIL to open the image
            image = Image.open(img_binary)

            # Perform OCR on the captured image
            extracted_text = pytesseract.image_to_string(image)

            # Insert the extracted text into the database
            connection = get_db_connection()
            if connection:
                cursor = connection.cursor()
                cursor.execute(
                    "INSERT INTO softcopies (filename, extracted_text) VALUES (%s, %s)",
                    ('captured_image.png', extracted_text)
                )
                connection.commit()
                cursor.close()
                connection.close()

            return render_template('softcopy.html', extracted_text=extracted_text)

    return render_template('softcopy.html', extracted_text=extracted_text)


@app.route('/registration_record')
def registration_record():
    """Retrieve and display registration records."""
    try:
        connection = get_db_connection()
        if connection:
            cursor = connection.cursor()
            cursor.execute("SELECT * FROM visitors")
            visitors = cursor.fetchall()
            cursor.close()
            connection.close()
        else:
            print("Failed to connect to the database.")
            visitors = []
    except pymysql.MySQLError as e:
        print(f"MySQL Error: {e}")
        visitors = []
    except Exception as e:
        print(f"Error retrieving data: {e}")
        visitors = []

    return render_template('registration_record.html', visitors=visitors)

@app.route('/softcopy_record')
def softcopy_record():
    """Retrieve and display softcopy records."""
    try:
        connection = get_db_connection()
        if connection:
            cursor = connection.cursor()
            cursor.execute("SELECT * FROM softcopies")
            softcopy_records = cursor.fetchall()
            cursor.close()
            connection.close()
            print("test",softcopy_records)
        else:
            softcopy_records = []
    except Exception as e:
        print(f"Error retrieving data: {e}")
        softcopy_records = []
        
    return render_template('softcopy_record.html', records = softcopy_records)

@app.route('/feedback', methods=['GET', 'POST'])
def feedback():
    """Render the feedback page and handle form submission."""
    if request.method == 'POST':
        email = request.form['email']
        message = request.form['message']
        
        # Logic to handle the feedback submission
        try:
            # You can send the feedback via email, store it in a database, etc.
            print(f"Feedback received from {email}: {message}")
            # For this example, we just print it to the console

            # Redirect to a thank you page or back to the home page after submission
            return redirect(url_for('home'))
        except Exception as e:
            print(f"Error: {e}")  # Print any error that occurs
            return "There was an error submitting your feedback."

    return render_template('feedback.html')

@app.errorhandler(404)
def page_not_found(e):
    """Render a custom 404 page.""" 
    return render_template('404.html'), 404  # Make sure to create a 404.html template

if __name__ == '__main__':
    app.run(debug=True)
