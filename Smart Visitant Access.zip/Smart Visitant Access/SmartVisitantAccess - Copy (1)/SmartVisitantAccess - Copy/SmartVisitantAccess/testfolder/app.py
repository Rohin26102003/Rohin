import mysql.connector

# Database configuration
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # Your MySQL password
    'database': 'visitordb'  # Your database name
}

# Create database connection
def get_db_connection():
    try:
        connection = mysql.connector.connect(**db_config)
        return connection
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return None

# Function to get user input and insert it into the database
def insert_hardcopy_document():
    # Get user input
    filename = input("Enter the document name (filename): ")
    extracted_text = input("Enter the extracted text: ")

    try:
        # Connect to the database
        connection = get_db_connection()
        if connection:
            cursor = connection.cursor()
            # Insert the user input into the 'hardcopy_documents' table
            cursor.execute(
                "INSERT INTO hardcopy_documents (filename, extracted_text) VALUES (%s, %s)",
                (filename, extracted_text)
            )
            connection.commit()
            print(f"Data successfully inserted: {filename}, {extracted_text}")

            # Close the connection
            cursor.close()
            connection.close()

        else:
            print("Error: Could not connect to the database.")
    except Exception as e:
        print(f"Error: {e}")
        print("There was an error inserting the data.")

if __name__ == '__main__':
    insert_hardcopy_document()
